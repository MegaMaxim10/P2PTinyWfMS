package inria.smarttools.core.util;

import inria.smarttools.core.component.Container;
import inria.smarttools.core.component.Message;

public interface MulticastProvider {

	public void notifyDisconnection(Container abstractContainer, String cmpName);

	public void send(Container source, Message msg);

}

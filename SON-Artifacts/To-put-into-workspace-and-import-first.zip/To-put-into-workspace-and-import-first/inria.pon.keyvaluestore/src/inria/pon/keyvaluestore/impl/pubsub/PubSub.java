package inria.pon.keyvaluestore.impl.pubsub;


public class PubSub {

}

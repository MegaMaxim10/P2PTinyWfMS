package inria.pon.keyvaluestore.framework;


public interface KeyListener {

}
